MegaAtoms
=========

Atoms for the MegaDrive (Genesis)!

This is the rom of MegaAtoms
this is part of a you tube series on making a game for the megadrive.
https://www.youtube.com/channel/UC5Ee7qQWiSZDcdTnXB6fBfw

This was developed using using SGDK




Classic Mode
============
    Classic Mode is 6 player multi-player game in which you have to create take control of the playing board. 
    You can play it in hot seat mode against 5 other people, or against (quite stupid) AI players.



    How To Play
    -----------
    Place your atoms on any empty square or stack them on top of your own, but when the numbers get too high they will go critical! 
    When it explodes it will send atoms flying and end up stacking on the atoms around it.
    Which not long increases the size of the stack but also put the stack under your control. 
    This is the key to taking over the gaming board.



    Input
    -----
    Currently the game is playable only using the first controller. Press start once you've setup the game then press A to place Atoms.





Challenge Mode
==============
    Challenge Mode is a single player game where the goal is to get as high a score as possible while hitting the targets.


    How to Play
    -----------
    The core actions are the same as in classic mode, but you have to explode the number of atoms indicated by the numbers on the left.
    When all these are done then you will go up a level and have a higher target to hit.
    Each time you make an atom go critical you will gain points and time.
    The Score multipler goes up with each chain reaction started, it is capped at the current level.
    If all the Atoms end up the same colour or if there are no free space then you will get a time penalty.
    It is game over when you run out of time.





History
=======

	V0.4.1
	------
	Fixed crashing when using a 4mb cart to play the game.
	Code that needs to happen in a v-blank can now do so easily
	Game should play correctly when the hardware resets.
	Move most of the states over to using the global pad struct.

	V0.4
	----
	Pause Screen added to Classic and Challenge
	High score table added to Challenge
	High scores saved to sram
	Progress bars added to Classic
	New artwork for professors and robots for Classic mode
	Tutorial added to Challenge mode


	V0.3.1
	------
	Bug fix release. 
	Tutorial works again.
	Can play challenge mode multiple times.
	Graphical corruption fixes.


	V0.3
	----
	Challenge mode added
	new Animation for the title screen
	Updated Character art


	V0.2
	----
	Idle Animations added
	Game cursor returns to the last place a player was
	Player select screen improvements
	Numerous bug fixes

	
	V0.1
	----
	First release, included classic mode.