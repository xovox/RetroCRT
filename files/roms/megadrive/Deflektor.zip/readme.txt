Deflektor v1.1
--------------------------------------------------------------------------------
A puzzle game based on mirrors reflecting a laser beam.  More fun
than it sounds.

The idea of the game is to work though succesive screens until
you run out of lives.  The idea of each screen is to direct the
laser beam into the receiver, but normally the receiver is
covered by a barrier that will only be removed once all of the
nodes have been destroyed, which again is done by directing the
laser beam into them.

To actually direct the beam, you can move your cursor around the
screen using the controls.  If you move the cursor over the top
of a mirror, and then hold down the select button, the left and
right keys will then rotate the mirror anti/clockwise,
redirecting the laser as it does so.

You only have a certain amount of time to complete each screen
(indicated by the energy bar).  Once this gets low, the laser
beam will start to flicker, and eventually you will lose a life. 
Should the laser beam be directed towards certain items, like
back to the original laser or onto spikes, then the laser will
start to overload.  Once the overload graph reaches a certain
point you will lose a life, and have to start the level again.

There are various other items on the screens which are there to
help and hinder you.  These include blocks which only allow the
laser to move through them in certain directions, automatically
rotating mirrors, blocks which redirect the laser randomly, and
also phantoms which interfere with your mirrors.

Check updates on my web site : 
http://www.portabledev.com


--------------------------------------------------------------------------------
History :
--------------------------------------------------------------------------------
V1.1 : 2019/06/10
	fix overload bar refresh
	Music rearranged by DavidKBD 
	fix laser beam update for faster game (now updated 1 frame out of 4)
	change compiler and lib for last SGDK version (1.40)
	fix fading when level is complete
	add password management for all 63 levels (yeah !!!)
	fix hiscore bug when entering name
	fix gremlins movement and map changing
V1.0 : 2019/06/02
	first attempt to port to MD

--------------------------------------------------------------------------------
Credits:
--------------------------------------------------------------------------------
Really great thanks foxy for giving me your source code about this game.

--------------------------------------------------------------------------------
Alekmaul
alekmaul@portabledev.com
http://www.portabledev.com
--------------------------------------------------------------------------------
