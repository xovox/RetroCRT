Old Towers (SEGA Mega Drive and Genesis)
--------------------------------------------------

v1.2
----
*Fixed cram dots during fades
*Fixed minor music bugs

v1.1
----
*Perfomance boost
*Fixed random crashes on some MD consoles

OLD TOWERS is a brand new homebrew game for the SEGA Mega Drive and Genesis.

You play as a little explorers in a towers full of deadly traps and ugly skullz.
Your only weapons to help you win: quick-thinking and skill.

OLD TOWERS is programmed with C language powered by SGDK.

Inspired by Tomb Of The Mask from Playgendary

See license.txt for details

Game by Denis Grachev
Music by Oleg Nikitin

Made with SGDK by Stephane Dallongeville
https://stephane-d.github.io/SGDK/

Game OST: https://soundcloud.com/n1k-o/sets/segaoldtowers-ost

contact us at: submit@retrosouls.net