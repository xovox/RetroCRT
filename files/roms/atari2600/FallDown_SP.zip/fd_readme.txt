                    FALL DOWN
                     2 6 0 0
                    ---------
                       --- 


About
=====
Fall Down pits the ever-opposed forces of RED and BLUE
against each other in an ultimate battle to capture
scrolling platforms!

The first player to fall past a platform captures it and
scores a point.  Taking time to collect power-ups can
give some advantage, but taking too long only results in
death at the top of the screen.  Watch out, because the
platforms slowly accelerate...

Fall Down includes both two-player and single-player
modes against an AI.




Game Modes
==========
Pressing select on the title screen changes the game
mode.  In order, these are:

Human vs. AI
Human vs. AI, easy mode (EZ)
Human vs. AI, advanced mode (down arrow)
Human vs. AI, pass-by mode (left/right arrows)
Human vs. AI, invisibility mode (the eye)
Single player
Human vs. Human
Human vs. Human, advanced mode
Human vs. Human, pass-by mode
Human vs. Human, invisibility mode

Easy mode makes the AI somewhat less effective.

Advanced mode greatly increases the starting scroll
speed.

Pass-by mode allows the players to pass by each other,
instead of bouncing off each other as in the other modes.

Invisibility mode alternates the background color so
that one of the players is invisibile for a short time.




In-Game Controls
================
                        Jump*

                          ^
                          |
            Move Left  <--O-->  Move Right
                          |
                          v

                         ---

Fire - Use power-ups.

Reset - Restart the game.

Select - Return to the title screen.

B&W/Color** - Pause the game.

Difficulty Switches -  Independently control whether
players wrap around (amateur) or bounce off (pro) the
edge of the screen.  Use these for handicap.

* Jumps are proportional; tapping up lightly results
  in a short jump, holding up jumps much higher.

** The Atari 7800 replaced the B&W/Color switch with
  a pause button.  Fall Down will attempt to detect
  this and act accordingly.




The Power-up System
===================
Occassionally you can collect power-ups, which are then
displayed under your score.  Pressing fire will use all
the power-ups you've collected, but the effects vary
based on how many you have:

1 gives a short speed boost.
2 digs a hole in the platform beneath you.
3 gives a long speed boost.
4 swaps places with the other player in 2-player mode,
  or teleports to the bottom of the screen in 1-player
  mode.



Contact the Author
==================
Fall Down is copyright � 2005 by Aaron Curtis
email:  aaron@mobilegamelab.com



Special Thanks To
=================
Nathan Strum, for the awesome character sprites.
Dennis Debro, for figuring out that rolling problem.
Albert Yarusso, because he's the man.
And everyone on [stella] and the AtariAge homebrew forum.